import 'package:dio/dio.dart';
import '../models/ticket_model.dart';
import 'api_client.dart';

class TicketService {
  final ApiClient _apiClient;

  TicketService(this._apiClient);

  Future<Map<String, dynamic>> bookTicket(BookTicketRequest request) async {
    try {
      final response = await _apiClient.dio.post(
        '/tickets/passenger/book',
        data: request.toJson(),
      );
      return response.data;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<List<TicketModel>> getUserTickets() async {
    try {
      final response = await _apiClient.dio.get('/tickets/passenger/my-tickets');
      final List<dynamic> data = response.data['data'];
      return data.map((json) => TicketModel.fromJson(json)).toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<TicketModel> getTicketById(String id) async {
    try {
      final response = await _apiClient.dio.get('/tickets/$id');
      return TicketModel.fromJson(response.data['data']);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Map<String, dynamic>> cancelTicket(String ticketId) async {
    try {
      final response = await _apiClient.dio.post('/tickets/$ticketId/cancel');
      return response.data;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  String _handleError(DioException e) {
    if (e.response != null) {
      return e.response?.data['message'] ?? 'An error occurred';
    } else {
      return 'Network error. Please check your connection.';
    }
  }
}

import 'package:dio/dio.dart';
import '../models/user_model.dart';
import 'api_client.dart';

class AuthService {
  final ApiClient _apiClient;

  AuthService(this._apiClient);

  Future<AuthResponse> register({
    required String username,
    required String email,
    required String password,
    required String phone,
    required String role,
    String? aadhaarNumber,
    DateTime? dateOfBirth,
    String? fullName,
    String? gender,
    Address? address,
    GovernmentIDs? governmentIds,
  }) async {
    try {
      final response = await _apiClient.dio.post(
        '/auth/register',
        data: {
          'username': username,
          'email': email,
          'password': password,
          'phone': phone,
          'role': role,
          if (aadhaarNumber != null) 'aadhaar_number': aadhaarNumber,
          if (dateOfBirth != null) 'date_of_birth': dateOfBirth.toIso8601String(),
          if (fullName != null) 'full_name': fullName,
          if (gender != null) 'gender': gender,
          if (address != null) 'address': address.toJson(),
          if (governmentIds != null) 'government_ids': governmentIds.toJson(),
        },
      );

      final authResponse = AuthResponse.fromJson(response.data['data']);
      _apiClient.setToken(authResponse.token);
      return authResponse;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<AuthResponse> login({
    required String username,
    required String password,
  }) async {
    try {
      final response = await _apiClient.dio.post(
        '/auth/login',
        data: {
          'username': username,
          'password': password,
        },
      );

      final authResponse = AuthResponse.fromJson(response.data['data']);
      _apiClient.setToken(authResponse.token);
      return authResponse;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<UserModel> getProfile() async {
    try {
      final response = await _apiClient.dio.get('/auth/profile');
      return UserModel.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Map<String, dynamic>> getSubsidyEligibility() async {
    try {
      final response = await _apiClient.dio.get('/auth/subsidy-eligibility');
      return response.data;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  void logout() {
    _apiClient.clearToken();
  }

  String _handleError(DioException e) {
    if (e.response != null) {
      return e.response?.data['message'] ?? 'An error occurred';
    } else {
      return 'Network error. Please check your connection.';
    }
  }
}

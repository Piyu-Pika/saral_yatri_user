import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/models/station_model.dart';

class StationMarkerWidget extends StatelessWidget {
  final StationModel station;

  const StationMarkerWidget({
    Key? key,
    required this.station,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _showStationInfo(context);
      },
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.stationMarker,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: const Icon(
          Icons.location_on,
          color: Colors.white,
          size: 20,
        ),
      ),
    );
  }

  void _showStationInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(station.stationName),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Code: ${station.stationCode}'),
            Text('Type: ${station.stationType.toUpperCase()}'),
            if (station.isAccessible)
              const Text('• Wheelchair Accessible'),
            if (station.facilities.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('Facilities:'),
              ...station.facilities.map((facility) => Text('• $facility')),
            ],
            if (station.operatingHours != null) ...[
              const SizedBox(height: 8),
              Text('Hours: ${station.operatingHours!.openTime} - ${station.operatingHours!.closeTime}'),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

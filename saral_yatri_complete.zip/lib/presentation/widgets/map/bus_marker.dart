import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/models/bus_model.dart';

class BusMarkerWidget extends StatelessWidget {
  final BusModel bus;

  const BusMarkerWidget({
    Key? key,
    required this.bus,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _showBusInfo(context);
      },
      child: Container(
        decoration: BoxDecoration(
          color: _getBusColor(),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: const Icon(
          Icons.directions_bus,
          color: Colors.white,
          size: 24,
        ),
      ),
    );
  }

  Color _getBusColor() {
    switch (bus.currentStatus) {
      case 'in_transit':
        return AppColors.success;
      case 'stopped':
        return AppColors.warning;
      case 'maintenance':
        return AppColors.error;
      default:
        return AppColors.busMarker;
    }
  }

  void _showBusInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(bus.busNumber),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Fleet: ${bus.fleetNumber}'),
            Text('Type: ${bus.busType.toUpperCase()}'),
            Text('Status: ${bus.currentStatus.toUpperCase()}'),
            Text('Capacity: ${bus.specifications.seatingCapacity} seats'),
            if (bus.specifications.hasAirConditioning)
              const Text('• Air Conditioned'),
            if (bus.specifications.hasWifi)
              const Text('• WiFi Available'),
            if (bus.specifications.isAccessible)
              const Text('• Wheelchair Accessible'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

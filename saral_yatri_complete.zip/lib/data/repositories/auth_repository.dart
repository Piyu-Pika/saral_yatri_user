import 'package:dio/dio.dart';
import 'package:dev_log/dev_log.dart';
import '../models/user_model.dart';
import '../../core/network/api_client.dart';
import '../../core/constants/app_constants.dart';
import '../../core/services/storage_service.dart';

class AuthRepository {
  Future<UserModel?> login(String email, String password) async {
    try {
      final response = await ApiClient.post(
        AppConstants.loginEndpoint,
        data: {
          'email': email,
          'password': password,
        },
      );

      if (response.statusCode == 200) {
        final data = response.data;
        final user = UserModel.fromJson(data['user']);
        final token = data['token'];

        // Store user data and token
        await StorageService.setString(AppConstants.userTokenKey, token);
        await StorageService.setObject(AppConstants.userDataKey, user.toJson());
        await StorageService.setBool(AppConstants.isLoggedInKey, true);

        DevLog.info('Login successful for user: ${user.email}');
        return user;
      }
      return null;
    } on DioException catch (e) {
      DevLog.error('Login failed: ${e.message}');
      throw Exception('Login failed: ${e.response?.data['message'] ?? e.message}');
    } catch (e) {
      DevLog.error('Unexpected error during login: $e');
      throw Exception('An unexpected error occurred');
    }
  }

  Future<UserModel?> register({
    required String name,
    required String email,
    required String password,
    required String phone,
  }) async {
    try {
      final response = await ApiClient.post(
        '/auth/register',
        data: {
          'name': name,
          'email': email,
          'password': password,
          'phone': phone,
        },
      );

      if (response.statusCode == 201) {
        final data = response.data;
        final user = UserModel.fromJson(data['user']);
        final token = data['token'];

        // Store user data and token
        await StorageService.setString(AppConstants.userTokenKey, token);
        await StorageService.setObject(AppConstants.userDataKey, user.toJson());
        await StorageService.setBool(AppConstants.isLoggedInKey, true);

        DevLog.info('Registration successful for user: ${user.email}');
        return user;
      }
      return null;
    } on DioException catch (e) {
      DevLog.error('Registration failed: ${e.message}');
      throw Exception('Registration failed: ${e.response?.data['message'] ?? e.message}');
    } catch (e) {
      DevLog.error('Unexpected error during registration: $e');
      throw Exception('An unexpected error occurred');
    }
  }

  Future<void> logout() async {
    try {
      await StorageService.remove(AppConstants.userTokenKey);
      await StorageService.remove(AppConstants.userDataKey);
      await StorageService.setBool(AppConstants.isLoggedInKey, false);
      DevLog.info('User logged out successfully');
    } catch (e) {
      DevLog.error('Error during logout: $e');
    }
  }

  Future<UserModel?> getCurrentUser() async {
    try {
      final userData = StorageService.getObject(AppConstants.userDataKey);
      if (userData != null) {
        return UserModel.fromJson(userData);
      }
      return null;
    } catch (e) {
      DevLog.error('Error getting current user: $e');
      return null;
    }
  }

  Future<bool> isLoggedIn() async {
    try {
      final isLoggedIn = StorageService.getBool(AppConstants.isLoggedInKey) ?? false;
      final token = StorageService.getString(AppConstants.userTokenKey);
      return isLoggedIn && token != null;
    } catch (e) {
      DevLog.error('Error checking login status: $e');
      return false;
    }
  }
}
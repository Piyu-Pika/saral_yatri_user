# Fonts

Add your custom fonts here:
- Poppins-Regular.ttf
- Poppins-Medium.ttf
- Poppins-SemiBold.ttf
- Poppins-Bold.ttf

You can download Poppins font from Google Fonts: https://fonts.google.com/specimen/Poppins